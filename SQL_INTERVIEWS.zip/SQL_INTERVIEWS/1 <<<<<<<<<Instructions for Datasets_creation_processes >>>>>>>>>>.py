# Databricks notebook source
# MAGIC %md
# MAGIC ##Agenda
# MAGIC
# MAGIC ###1 Creation of Tables/Dataframes
# MAGIC    - Tables
# MAGIC    - Dtaframes
# MAGIC    - Upload data to tables(previously created)
# MAGIC
# MAGIC ###2 Pyspark Tips  
# MAGIC     1  Select() vs selectExpr()
# MAGIC     2  Grouping vs agg()
# MAGIC     3  where/filter/having
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![image_1774641577007.png](./image_1774641577007.png "image_1774641577007.png")
# MAGIC ### 1 Creation of tables/Dataframes

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC 1 Create empty tables for employees and departments
# MAGIC
# MAGIC     Notebook: employee_department_Create_tables_creation
# MAGIC
# MAGIC 2 Create empty tables for customers, orders, products, returns
# MAGIC
# MAGIC     Notebook: customers_orders_products_returns_tables_Creation
# MAGIC
# MAGIC 3 Create dataframes for employees and departments
# MAGIC
# MAGIC     NOtebook: employee_department_dataframe_creation. 
# MAGIC               You can directly WORK with these dataframes or 
# MAGIC               Run teh dataframe, copy the data and paste it in a csv file. Then upload the csv to the VOLUME and use it from there
# MAGIC
# MAGIC               UPLOAD -->
# MAGIC               Click on  to Catalog (dev) , spark_dv, Volumes, Datasets, spark_programming, select 'data' folder.
# MAGIC               If the file exists then delete it firt: Mark the chekbox next to the desired cvs file and click delete
# MAGIC               If teh file does not exist then upload it: Click on the top-right "Upload to Volume' bottom and upload files              
# MAGIC
# MAGIC 4 Create dataframes for customers, orders, products, returns 
# MAGIC
# MAGIC     Notebook: customer_products_orders_returns_dataframe_Creation
# MAGIC               You can directly WORK with these dataframes or 
# MAGIC               Run teh dataframe, copy the data and paste it in a csv file. Then upload the csv to the VOLUME and use it from there
# MAGIC               
# MAGIC               UPLOAD -->
# MAGIC               Click on  to Catalog (dev) , spark_dv, Volumes, Datasets, spark_programming, select 'data' folder.
# MAGIC               If the file exists then delete it firt: Mark the chekbox next to the desired cvs file and click delete
# MAGIC               If teh file does not exist then upload it: Click on the top-right "Upload to Volume' bottom and upload files
# MAGIC
# MAGIC 5 Upload the data from those csv files to each of teh tables previously created employee/department
# MAGIC
# MAGIC     Notebook: Employee_department-spark-session
# MAGIC               Read teh CSV
# MAGIC               Fix any datatype discrepancies
# MAGIC               Load the data from the csv to each of the tables previously created  
# MAGIC               Query those tables
# MAGIC
# MAGIC 6 Upload the data from those csv files to each of teh tables previously created customer/orders/products/returns
# MAGIC
# MAGIC     Notebook: customers_products_orders_returns-spark-session
# MAGIC               Read teh CSV
# MAGIC               Fix any datatype discrepancies
# MAGIC               Load the data from the csv to each of the tables previously created   
# MAGIC               Query those tables
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![image_1774482745209.png](./image_1774482745209.png "image_1774482745209.png")
# MAGIC ### 2 Pyspark Tips
# MAGIC
# MAGIC '
# MAGIC
# MAGIC ![image_1774641851028.png](./image_1774641851028.png "image_1774641851028.png")
# MAGIC #### 1 select() vs selectExtr()
# MAGIC   -     Both methods return a new DataFrame and are used for selecting and transforming columns
# MAGIC
# MAGIC ##### The core difference is that
# MAGIC        * select() uses PySpark's Column API with expressions
# MAGIC        * selectExpr() accepts standard SQL expressions as strings.
# MAGIC
# MAGIC ![image_1774458253140.png](./image_1774458253140.png "image_1774458253140.png")
# MAGIC ![image_1774457128402.png](./image_1774457128402.png "image_1774457128402.png")
# MAGIC
# MAGIC '
# MAGIC
# MAGIC ---------------------------------------------------------------------
# MAGIC ####1.1 select()
# MAGIC Key Point: select() is useful when you need to perform column selection or basic transformations.
# MAGIC ![image_1774457763357.png](./image_1774457763357.png "image_1774457763357.png")
# MAGIC
# MAGIC ###### Examples
# MAGIC
# MAGIC ![image_1774458064009.png](./image_1774458064009.png "image_1774458064009.png")
# MAGIC
# MAGIC '
# MAGIC '
# MAGIC
# MAGIC ---------------------------------------------------------------------
# MAGIC
# MAGIC ####1.2 selectExpr()
# MAGIC Key Point: selectExpr() is powerful for complex transformations, calculations, or applying SQL functions inline, allowing more flexibility in how data is selected and manipulated.
# MAGIC
# MAGIC ![image_1774457783339.png](./image_1774457783339.png "image_1774457783339.png")
# MAGIC
# MAGIC ###### Examples
# MAGIC
# MAGIC ![image_1774458087222.png](./image_1774458087222.png "image_1774458087222.png")
# MAGIC
# MAGIC
# MAGIC ### GROUP BY operation directly in selectExpr(). First need to register your DataFrame as a temporary SQL view 
# MAGIC
# MAGIC   -     Using selectExper() To calculate the revenue for each productid in PySpark, you first need to register your DataFrame as a temporary SQL view 
# MAGIC         and then execute a SQL query. 
# MAGIC
# MAGIC         PySpark's selectExpr() is designed to run SQL expressions on an existing DataFrame, not to perform a 
# MAGIC         GROUP BY operation directly.
# MAGIC
# MAGIC .
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![image_1774641851028.png](./image_1774641851028.png "image_1774641851028.png")
# MAGIC
# MAGIC #### 2 groupBy() and agg()
# MAGIC
# MAGIC .
# MAGIC
# MAGIC ### selectExpr() 
# MAGIC ##### In PySpark  You can use selectExpr() to perform aggregations in two primary ways: 
# MAGIC
# MAGIC   -     1 Grouped Aggregation (after a groupBy()).  Use groupBy() then use agg() or selectExpr() 
# MAGIC   -     2 Global Aggregation: either on the entire DataFrame 

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### 1. Grouped Aggregation (after groupBy())  <<This is the STANDARD/COMMON way>>
# MAGIC To aggregate data within specific groups, you 
# MAGIC    - first use groupBy() and then
# MAGIC    - use agg() or selectExpr() on the resulting GroupedData object. 
# MAGIC
# MAGIC Note that selectExpr() is generally called after the groupBy to select the final columns, which often results in the same effect as using agg()
# MAGIC
# MAGIC A common approach to applying aggregation expressions using SQL syntax within the DataFrame API is to use the agg() method on the grouped data:
# MAGIC
# MAGIC ##### This is teh standard way in pyspark to groupe aggregations. THIS PIECE CONTAINS A field and aggregations but the field is grouped first
# MAGIC
# MAGIC ![image_1774468900290.png](./image_1774468900290.png "image_1774468900290.png")
# MAGIC
# MAGIC ![image_1774547384147.png](./image_1774547384147.png "image_1774547384147.png")
# MAGIC
# MAGIC
# MAGIC
# MAGIC ##### using selectExpr() after groupBy()
# MAGIC If you prefer to use selectExpr() after the groupBy(), you would typically register the DataFrame as a temporary view first, and then run a SQL query:

# COMMAND ----------

# Using selectExpr() with groupBy is less direct than using agg()
# A common pattern is to register a temp view and use spark.sql()
#df.createOrReplaceTempView("products_view")
#spark.sql("SELECT Product, AVG(Price) AS avg_price, SUM(Quantity) AS total_quantity FROM products_view GROUP BY Product").show()


# COMMAND ----------

# MAGIC %md
# MAGIC -------------------------------------------------------
# MAGIC
# MAGIC
# MAGIC #### 2. Global Aggregation (on the entire DataFrame) 
# MAGIC You can perform aggregations on the entire DataFrame without explicit grouping. This is a shorthand for df.groupBy().agg()

# COMMAND ----------

"""
from pyspark.sql import SparkSession

# Create a SparkSession (if not already created)
spark = SparkSession.builder.appName("selectExprAgg").getOrCreate()

# Sample DataFrame
data = [("Laptop", 1500, 10), 
        ("Mouse", 50, 200),
        ("Laptop", 1200, 5),
        ("Keyboard", 100, 50)]
columns = ["Product", "Price", "Quantity"]
df = spark.createDataFrame(data, columns)
df.show()


# Global aggregation using selectExpr()
df.selectExpr(
    "avg(Price) AS avg_price",
    "sum(Quantity) AS total_quantity",
    "count(Product) AS total_products"
).show()
"""

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ###### This piece of teh above code DOES NOT CONTAINM A FIELD and aggregations, ONLY AGGREGATIONS
# MAGIC
# MAGIC ![image_1774468850948.png](./image_1774468850948.png "image_1774468850948.png")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Pay attention to the output as the last piece DOES NOT CONTAIN fields, just the entire aggregation
# MAGIC ![image_1774468340248.png](./image_1774468340248.png "image_1774468340248.png")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![image_1774641851028.png](./image_1774641851028.png "image_1774641851028.png")
# MAGIC #### 3  where/filter/having

# COMMAND ----------

# MAGIC %md
# MAGIC ##### In PySpark
# MAGIC ###### where() and filter() 
# MAGIC Both are used to filter rows based on a given condition, similar to the SQL WHERE clause. They are interchangeable and can accept boolean expressions or SQL-style string conditions
# MAGIC
# MAGIC ###### having() 
# MAGIC In PySpark, 'having' IS NOT USED. You have two options instead:
# MAGIC   -     Applying a filter() or where() condition after the groupBy() and aggregation steps have been performed
# MAGIC   -     Using SQL queries directly OR
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### SQL Query
# MAGIC
# MAGIC ![image_1774650780213.png](./image_1774650780213.png "image_1774650780213.png")
# MAGIC
# MAGIC .
# MAGIC
# MAGIC #####Pyspark
# MAGIC ![image_1774650889201.png](./image_1774650889201.png "image_1774650889201.png")
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![image_1774641851028.png](./image_1774641851028.png "image_1774641851028.png")
# MAGIC #### 4  tbd

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![image_1774641851028.png](./image_1774641851028.png "image_1774641851028.png")
# MAGIC #### 5  tbd

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![image_1774641851028.png](./image_1774641851028.png "image_1774641851028.png")
# MAGIC #### 6  tbd

# COMMAND ----------

